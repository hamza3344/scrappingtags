﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace scrapping
{
    public partial class Form1 : Form
    {
        HtmlAgilityPack.HtmlWeb web = new HtmlAgilityPack.HtmlWeb();//create the object
        HtmlAgilityPack.HtmlDocument doc;//create the object
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            doc = web.Load("https://en.wikipedia.org/wiki/Web_scraping");//load the page
            gettagsvalue("h2", -1);//get the first 5 header 2
            MessageBox.Show("get links");
            gettagsvalue("a[@href]", 10, true);
            MessageBox.Show("Paragraphs");
            gettagsvalue("p", 5);//get first 5 paragraphs

        }
        void gettagsvalue(string tagname,int limit=20,bool href=false)
        {
            var tags = doc.DocumentNode.SelectNodes("//" + tagname);
            if(href==false)
            {
                int i = 0;
                foreach(var tag in tags)
                {
                    i = i + 1;
                    if(limit==i)
                    {
                        break;
                    }
                    MessageBox.Show(tag.InnerText);
                }
            }
            else if(href==true)
            {
                int i = 0;
                foreach (var tag in tags)
                {
                    i = i + 1;
                    if (limit == i)
                    {
                        break;
                    }
                    string Value = tag.GetAttributeValue("href", string.Empty);
                    MessageBox.Show(Value);
                }
            }
        }
    }
}
